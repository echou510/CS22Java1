
/**
 * Write a description of class A here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class A {
   public static void main(String[] args){
     for (int i=0; i<args.length; i++) 
          System.out.println(args[i]); 
   }
} 
