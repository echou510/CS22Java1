import java.util.Arrays; 
/**
 * Write a description of class AP2_Transcopy here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AP2_Transcopy
{
     public static double[] list = {1.0, 2.0, 3.0, 4.0, 5.0, 
                                   6.0, 7.0, 8.0, 9.0, 10.0};
     
     public static double[] source = {11.0, 12.0, 13.0}; 
                                   
     public static void transcopy(double[] source, double[] destination, int start){
         if (start+source.length> destination.length) return; 
         int p=start; 
         for (int i=0; i<source.length; i++){
             destination[p++] = source[i];   
          }
      }                              
     public static void main(String[] args){
         System.out.print("\f");
         System.out.println("Source: "+Arrays.toString(source)); 
         System.out.println("Destination: "+Arrays.toString(list));
         transcopy(source, list, 3); 
         System.out.println("Destination after Transcopy: "+Arrays.toString(list)); 
      }
}
