
/**
 * Write a description of class ArgsArrayTester here.
 * 
 * @author (Eric Y. Chou) 
 * @version (07/25/2019)
 */
public class ArgsArrayTester
{
    public static void main(String[] args){
       for (int i = 0; i<args.length; i++){
           System.out.println("Main Argument ["+i+"]= "+args[i]);
        }
    }
}
