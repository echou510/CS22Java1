import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator; 
import java.util.List;
import java.util.Arrays;
/**
 * Write a description of class ArrayListProcessingII here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/06/2015)
 */
public class ArrayListProcessingII
{
  static class Student{  
    int rollno;  
    String name;  
    int age;  
    Student(int rollno,String name,int age){  
     this.rollno=rollno;  
     this.name=name;  
     this.age=age;  
    }  
  }  
  public static void arrayListLoopingExample() {
        System.out.println("ArrayList Traversal Examples:............"); 
		ArrayList<String> list = new ArrayList<String>();
		list.add("Text 1");
		list.add("Text 2");
		list.add("Text 3");

		System.out.println("#1 normal for loop");
		for (int i = 0; i < list.size(); i++) { // for-loop 
			System.out.print(list.get(i)+" ");
		}
		System.out.println(); 

		System.out.println("#2 advance for loop");
		for (String temp : list) {  // for-each loop
			System.out.print(temp+" ");
		}
		System.out.println(); 
		System.out.println("#3 while loop");
		int j = 0;
		while (list.size() > j) { // while-loop
			System.out.print(list.get(j)+" ");
			j++;
		}
		System.out.println(); 
		System.out.println("#4 iterator");
		Iterator<String> iterator = list.iterator();
		while (iterator.hasNext()) {
			System.out.print(iterator.next()+" ");
		}
	    System.out.println(); 
   }
   
  public static void iteratorExample() {
    System.out.println("ArrayList Iterator Examples:............");
    ArrayList<String> al = new ArrayList<String>();

    al.add("C");
    al.add("A");
    al.add("E");
    al.add("B");
    al.add("D");
    al.add("F");

    System.out.print("Original contents of al: ");
    Iterator<String> itr = al.iterator();
    while (itr.hasNext()) {
      String element = itr.next();
      System.out.print(element + " ");
    }
    System.out.println();

    ListIterator<String> litr = al.listIterator();
    while (litr.hasNext()) {
      String element = litr.next();
      litr.set(element + "+");
    }

    // Now, display the list backwards.
    System.out.print("Modified list backwards: ");
    while (litr.hasPrevious()) {
      String element = litr.previous();
      System.out.print(element + " ");
    }
    System.out.println(); 
   }
  
  public static void userDefinedClass(){  
    System.out.println("ArrayList of User-defined Class Examples:............");    
    //Creating user-defined class objects  
    Student s1=new Student(101,"Sonoo",23);  
    Student s2=new Student(102,"Ravi",21);  
    Student s3=new Student(103,"Hanumat",25);  
      
    ArrayList<Student> al=new ArrayList<Student>();//creating arraylist  
    al.add(s1);//adding Student class object  
    al.add(s2);  
    al.add(s3);  
    
    Iterator itr=al.iterator();  
    //traversing elements of ArrayList object  
    while(itr.hasNext()){  
      Student st=(Student)itr.next();  
      System.out.println(st.rollno+" "+st.name+" "+st.age);  
    }  
   }   
   
   public static void occurrenceCountExample(){
      System.out.println("ArrayList of Character Occurence Counting Example:............");    
      char A='A'; char B='B';char C='C';char D='D';char E='E';char F='F';char G='G';char H='H';char I='I';
      char J='J'; char K='K';char L='L';char M='M';char N='N';char O='O';char P='P';char Q='Q';char R='R';    
      char S='S'; char T='T';char U='U';char V='V';char W='W';char X='X';char Y='Y';char Z='Z';   
      
      char[] cc = {A,J,A,H,F,A,E,I,R,U,I,J,F,K,S,A,J,F,K,D,S,A,K,F,H,J,D,S,H,F,D,S,N,M,A,N,R,W,E,M,H,F,J,
                   H,F,J,K,L,D,S,A,H,F,J,H,D,S,A,J,K,H,F,J,K,D,S,A,H,J,R,E,Y,W,O,H,F,D,S,J,F,L,K,A,J,F,K,
                   J,D,S,L,K,A,F,J,S,A,U,O,R,E,U,W,O,F,J,L,S,A,J,F,K,L,D,S,J,A,F,K,L,S,D,J,R,Q,P,U,R,I,Q,
                   E,J,T,J,Z,M,M,V,Z,C,X,N,V,A,D,J,K,A,S,J,F,S,P,R,E,W,Q,F,K,A,K,F,D,L,S};
      ArrayList<Character> cccc = new ArrayList<Character>(); 
      ArrayList<Integer>   freq = new ArrayList<Integer>(); 
      
      for (char c: cc){
          boolean found = false; 
           for (int i=0; i<cccc.size(); i++){
                if (cccc.contains(new Character(c))){
                    int j = cccc.indexOf(new Character(c));
                    int k =freq.get(j); k++; freq.set(j, k);  found = true;  break; 
                } 
            }
           if (!found) {cccc.add(c); freq.add(new Integer(1));} 
      }
      
      for (int i=0; i<cccc.size(); i++){
           System.out.print(cccc.get(i)+"="+freq.get(i)+"   ");
           if ((i+1) % 10 == 0) System.out.println(); 
        }
      System.out.println(); 
    }
   
   public static void reverseExample(){
      System.out.println("ArrayList Reverse Example:............");    
      char A='A'; char B='B';char C='C';char D='D';char E='E';char F='F';char G='G';char H='H';char I='I';
      char J='J'; char K='K';char L='L';char M='M';char N='N';char O='O';char P='P';char Q='Q';char R='R';    
      char S='S'; char T='T';char U='U';char V='V';char W='W';char X='X';char Y='Y';char Z='Z';   
       
      ArrayList<Character> original = new ArrayList<Character>(Arrays.asList(new Character[]{A, B, C, D, E}));
      ArrayList<Character> reverse = new ArrayList<Character>(); 
      for (int i=original.size()-1; i>=0; i--) reverse.add(original.get(i));
      System.out.println("Original="+original+"  Reverse="+reverse); 
   }
   
       public static int min(ArrayList<Integer> freq){
       //double max = myList[0];
       // for (int i = 1; i < myList.length; i++) {
       //   if (myList[i] > max) max = myList[i];
       // }
        int min = Integer.MAX_VALUE; 
        for (int i = 0;i< freq.size(); i++){
            if (freq.get(i).intValue() < min) min = freq.get(i).intValue(); 
        }
        return min; 
    }
     public static void occurrenceSortExample(){
      System.out.println("ArrayList of Character Occurence Counting Example:............");    
      char A='A'; char B='B';char C='C';char D='D';char E='E';char F='F';char G='G';char H='H';char I='I';
      char J='J'; char K='K';char L='L';char M='M';char N='N';char O='O';char P='P';char Q='Q';char R='R';    
      char S='S'; char T='T';char U='U';char V='V';char W='W';char X='X';char Y='Y';char Z='Z';   
      
      char[] cc = {A,J,A,H,F,A,E,I,R,U,I,J,F,K,S,A,J,F,K,D,S,A,K,F,H,J,D,S,H,F,D,S,N,M,A,N,R,W,E,M,H,F,J,
                   H,F,J,K,L,D,S,A,H,F,J,H,D,S,A,J,K,H,F,J,K,D,S,A,H,J,R,E,Y,W,O,H,F,D,S,J,F,L,K,A,J,F,K,
                   J,D,S,L,K,A,F,J,S,A,U,O,R,E,U,W,O,F,J,L,S,A,J,F,K,L,D,S,J,A,F,K,L,S,D,J,R,Q,P,U,R,I,Q,
                   E,J,T,J,Z,M,M,V,Z,C,X,N,V,A,D,J,K,A,S,J,F,S,P,R,E,W,Q,F,K,A,K,F,D,L,S};
      ArrayList<Character> cccc = new ArrayList<Character>(); 
      ArrayList<Integer>   freq = new ArrayList<Integer>(); 
      
      for (char c: cc){
          boolean found = false; 
           for (int i=0; i<cccc.size(); i++){
                if (cccc.contains(new Character(c))){
                    int j = cccc.indexOf(new Character(c));
                    int k =freq.get(j); k++; freq.set(j, k);  found = true;  break; 
                } 
            }
           if (!found) {cccc.add(c); freq.add(new Integer(1));} 
      }
      
      ArrayList<Character> newcccc = new ArrayList<Character>(); 
      ArrayList<Integer>   newfreq = new ArrayList<Integer>(); 
      int len = cccc.size(); 
      for (int i=0; i<len; i++){
           int min = min(freq); 
           Character ccc = cccc.get(freq.indexOf(min)); 
           Integer   iii = freq.get(freq.indexOf(min));
           newcccc.add(ccc); 
           newfreq.add(iii); 
           cccc.remove(freq.indexOf(min)); 
           freq.remove(freq.indexOf(min));
        }
      for (int i=0; i<newcccc.size(); i++){
           System.out.print(newcccc.get(i)+"="+newfreq.get(i)+"   ");
           if ((i+1) % 10 == 0) System.out.println(); 
        }
      System.out.println();  
    } 
    
   public static void main(String[] main){
       arrayListLoopingExample();
       iteratorExample();
       userDefinedClass();
       occurrenceCountExample();
       reverseExample();
       occurrenceSortExample();
    }
}
