import java.util.ArrayList; 
/**
 * Write a description of class AvailableList here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/10/2017)
 */
public class AvailableList extends ArrayList<Integer>
{
   public Integer randomPop(){
       if (this.size()==0) return 0;  // this line can be modified
       Integer i; 
       int ix = (int)(Math.random()*this.size());
       i = new Integer(this.remove(ix));  // remove means no longer available. 
       return i; 
    }
   public static void main(String[] args){
      int[] a={8, 7, 9, 5, 6, 11, 9, -3, 2, 0, 17, 5}; 
      AvailableList available = new AvailableList(); 
      for (int i: a){
            available.add(new Integer(i)); 
         }
      System.out.print("\f"); 
      for (int i=0; i<30; i++){
          System.out.println(available.randomPop()); 
        }
    }
}
