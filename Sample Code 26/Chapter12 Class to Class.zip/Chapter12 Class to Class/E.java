
/**
 * Write a description of class E here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class E
{
   public static double epsilon(int n){  // n >= 1 
       int fact=1;  double sum=0; 
       for (int i=1; i<=n; i++){
           fact = fact * i; 
           sum += (double) 1/fact; 
        }
       return sum+1;   // add the 1/0! into the sum to create natural exponential e
    }
    
   public static void main(String[] args){
      System.out.println("e="+epsilon(20)+" compared to "+Math.E); 
    }
}
