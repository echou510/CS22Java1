import java.math.BigInteger; 

/**
 * Write a description of class TestBigInteger here.
 * 
 * @author (Eric Y. Chou) 
 * @version (03/15/2016)
 */
public class TestBigInteger
{
   public static void main(String[] args){
     byte[] a = new byte[2000]; 
     
     // One 
     a[a.length-1] = (byte) 0b00000001;  // little ending, the last byte () is least significant
     BigInteger x = new BigInteger(a); 
     System.out.println("One: "+x);
     
     // BigInteger.MAX_VALUE
     for (int i = 1; i<a.length; i++){
          a[i] = (byte) 0xFF;  // set every bit 
        }
     a[0] = (byte) 0b01111111;   // set every bit except the first bit
     x = new BigInteger(a); 
     System.out.println("BigInteger.MAX_VALUE = " + x.toString()); 
    
    // BigInteger.MIN_VALUE
    byte[] b = new byte[2000]; 
     for (int i = 1; i<b.length; i++){
          b[i] = (byte) 0x00;  // set every bit 
        }
     //b[b.length-1] = (byte) 0b00000001;
     b[0] = (byte) 0b10000000;   // set every bit 
     BigInteger y = new BigInteger(b); 
     System.out.println("BigInteger.MIN_VALUE = " + y.toString()); 
     
     System.out.println("Now, let's work on that BigInteger...");
     
     byte[] c = new byte[2000]; 
     c[c.length-1] = (byte) 0b00000001;  // little ending, the last byte () is least significant
     BigInteger z = new BigInteger(c); 
     System.out.println("One created "+z);
     
     for (int i=0; i<1000; i++){  // 1 * 1000 * 1000 ... 1000 ( for 1000 times)
          z = z.multiply(new BigInteger("1000")); 
        }
     System.out.println("Your lovely 1000^1000: "+z);
    }      
}
