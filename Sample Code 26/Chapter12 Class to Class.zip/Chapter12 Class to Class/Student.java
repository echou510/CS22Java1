
/**
 * Write a description of class Student here.
 * 
 * @author (Eric Y. Chou) 
 * @version (01/10/2016)
 */
public class Student
{
   private Name name; 
   private Address addres; 
}
