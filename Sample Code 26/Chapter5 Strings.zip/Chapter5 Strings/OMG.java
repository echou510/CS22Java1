
/**
 * Write a description of class OMG here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OMG
{
    public static void main(String[] args){
      String originalMessage = "oh my god! i lost my high school backpack.  you may laugh out loud but this is a very big deal. in case you didn't know.  just for your information.";   

      String str1 = originalMessage.replaceAll("oh my god", "OMG"); 
      String str2 = str1.replaceAll("high school", "HS"); 
      String str3 = str2.replaceAll("laugh out loud", "LOL");
      String str4 = str3.replaceAll("very big deal", "VBD"); 
      String str5 = str4.replaceAll("in case you didn't know", "INCYDK"); 
      String str6 = str5.replaceAll("for your information", "FYI"); 
      System.out.println("ORIG: "+ originalMessage); 
      System.out.println("STR1: "+ str1); 
      System.out.println("STR2: "+ str2); 
      System.out.println("STR3: "+ str3); 
      System.out.println("STR4: "+ str4); 
      System.out.println("STR5: "+ str5); 
      System.out.println("STR6: "+ str6); 
    }
}
