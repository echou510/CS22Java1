
/**
 * Write a description of class ProgramOOP here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/15/2015)
 */
public class ProgramOOP
{   private String name;
    private String staticStr;
    // It is not a static String, just make it look similar to show the different program style. 
    ProgramOOP(){}
    ProgramOOP(String n, String str){
        name = n;         
        staticStr = str;   
    }
    public String getName() {return name; }
    public String getStr()  {return staticStr; }
    public void setName(String n) {name = n;}
    public void setStr(String str){staticStr = str;}
}
