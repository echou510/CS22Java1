
/**
 * Write a description of class ProgramStaticOnly here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/15/2015)
 */
public class ProgramStaticOnly
{
    private static String staticStr = "STATIC-STRING";
   
    public static void testStaticMethod(){
        System.out.println("Hey... I am in static method...");
        //you can call static variables here
        System.out.println(ProgramStaticOnly.staticStr);
        //you can not call instance variables here.
    }
    public static void testObjectMethod(String name){
        System.out.println("Hey i am in non-static method");
        //you can also call static variables here
        System.out.println(ProgramStaticOnly.staticStr);
        //you can call instance variables here
        System.out.println("Name: "+name);
    }     
    public static void main(String a[]){
        //By using class name, you can call static method
        ProgramStaticOnly.testStaticMethod();
        ProgramStaticOnly.testObjectMethod("Java Programming AP Edition");
    }
}
