
/**
 * Write a description of class ProgramStaticOnlyTwo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ProgramStaticOnlyTwo
{
    public static String staticStr = "STATIC-STRING";   
    public static void testStaticMethod(){
        System.out.println("Hey... I am in static method...");
        //you can call static variables here
        System.out.println(ProgramStaticOnlyTwo.staticStr);
        //you can not call instance variables here.
    }
    public static void main(String a[]){
        //By using class name, you can call static method
        ProgramStaticOnlyTwo.testStaticMethod();
        ProgramStaticOnlyTwoSub.testObjectMethod(ProgramStaticOnlyTwoSub.name);
    }
}
