
/**
 * Write a description of class CatapultTester here.
 * 
 * 1.The program is created to predict the distance of the projectile 
 * after it is shot from a tank at a certain angle and velocity.
 * 
 * 2.The projectile calculation is put in the projectile class.
 * 
 * 3.By using the equation of distance equals velocity squared times sin 2 theta divided by g,
 * I was able to calculate how far the projectile flew.
 * 
 * @author (Eric Y. Chou) 
 * @version (06/06/2016)
 */
public class CatapultTester
{  /**
     * x base value for velocity in MPH
     */
   final static int XBASE = 20; 
    /**
     * x step value value for velocity in MPH
     */
   final static int XSTEP = 5;
    /**
     * y base value for angle in degree
     */
   final static int YBASE = 25; 
    /**
     * y step value for angle in degree
     */
   final static int YSTEP = 5; 
    /**
     * gravity
     */
   final static double G = 9.81; 
    /**
     * distance
     */
   static double distance = 0.0;
   /**
    * Function getMPS finds the velocity in meter per second for each row of projecttiles.
    * 
    * @param x number of rows
    * @return row the total number of rows
    */
   public static int getMPS(int x){
       int row = XBASE + XSTEP * x;  
       return row; 
    }
    
   /**
    * Function to find the launch angle in degrees. 
    * 
    * @param y  the number of columns
    * @return col the total number of columns
    */
   public static int getDeg(int y){
       int col  = YBASE + YSTEP * y; 
       return col; 
    }
    
   /**
    *Function printHeader prints out the header of the program
    *
    *@return void none
    */
   public static void printHeader(Catapult[][] projectiles){
       System.out.println("                 Projectile Distance (feet)       ");
       System.out.printf("%4s  ", "MPS");
       for(int i = 0; i<projectiles[i].length; i++){
             System.out.printf("%5d deg", getDeg(i));
        }
        System.out.println("\n===============================================================");
        //System.out.println();
    }
    
   /**
    * Main function of the program
    * 
    * return void none
    */
   public static void main(String[] args){
       Catapult[][] projectiles = new Catapult[7][6];  // A 2D table of Catapult cells. 
       printHeader(projectiles);
       
       for (int i=0; i<projectiles.length; i++){
           System.out.printf("%4d   ", getMPS(i));
         for (int j=0; j<projectiles[i].length; j++){
             
              projectiles[i][j] = new Catapult(getMPS(i), getDeg(j), G);  
              distance = projectiles[i][j].findDistance();
              System.out.printf("%8.2f ", Catapult.toFeet(distance));
           }
           System.out.println();
        }
    }
}
