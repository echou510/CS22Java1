
/**
 * Write a description of class ProgramStaicOnlyTwoSub here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/15/2015)
 */
public class ProgramStaticOnlyTwoSub
{  public static String name =  "Java Programming AP Edition"; 
   public static void testObjectMethod(String name){
        System.out.println("Hey i am in non-static method");
        //you can also call static variables here
        System.out.println(ProgramStaticOnlyTwo.staticStr);
        //you can call instance variables here
        System.out.println("Name: "+name);
    }     
}
