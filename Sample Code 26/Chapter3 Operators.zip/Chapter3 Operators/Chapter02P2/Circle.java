
/**
 * Write a description of class Circle here.
 *
 * @author (Eric Y. Chou)
 * @version (03/22/2019)
 */
public class Circle{
    public static double PI = 3.1415926; 
    
    private double radius=0; 
  
    Circle(double r){
      radius = r; 
    }
    
    public double getRadius(){ return radius; }
    public double getArea(){ return PI*radius*radius; }
    public double getPerimeter(){ return 2*PI*radius; }
    /* turing on and off to see the hashCode */ 
    public String toString(){ return "Circle["+radius+"]"; }
}
