/**
 *  This program is to show basic variable declaration and initialization. 
 * 
 * @author (Eric Y. Chou)
 * @vesion (V1, 11/03/2015)
 */
public class ComputeAreaModified {
	  public static void main(String[] args) {
		    double radius; // Declare radius
		    double area; // Declare area
		    double perimeter; 

		    // Assign a radius
		    radius = 20; // New value is radius

		    // Compute area
		    area = radius * radius * 3.14159;
            perimeter = 3.14159 * 2 * radius; 
		    // Display results
		    System.out.println("The area for the circle of radius " +
		      radius + " is " + area);
		    System.out.println("The perimeter for the circle of radius " +
		      radius + " is " + perimeter);  
		  }
}
