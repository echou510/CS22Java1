/**
 * Write a description of class Repetition here.
 *
 * @author (Eric Y. Chou)
 * @version (07/02/2019)
 */
public class Repetition
{
    public static void main(){
      System.out.print("\f"); 
      for (int i=0; i<10; i++){
            System.out.println("Welcome");
        }
    }
}