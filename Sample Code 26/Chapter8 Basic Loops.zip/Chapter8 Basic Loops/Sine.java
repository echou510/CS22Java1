
/**
 * Write a description of class Sine here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sine
{
  public static void main(String[] args){
       final int STEPS = 24; 
       final int RESOLUTION = 100000; 
       double theta = Math.PI * 2.0 / STEPS; 
       double sine   = 0.0; 
       double cosine = 0.0; 
       System.out.println("            Sine/Cosine Table ");
       System.out.printf("%17s", " ");
       System.out.printf("  %7s  ", "Sine");
       System.out.printf("   %7s  %n", "Cosine");
       System.out.println("=========================================="); 
       for (int i=0; i<=STEPS; i++){
           sine   = Math.sin(theta*i) ; 
           cosine = Math.cos(theta*i); 
           //sine   = (int)(Math.sin(theta*i)*RESOLUTION)/(double) RESOLUTION ; 
           //cosine = (int)(Math.cos(theta*i)*RESOLUTION)/(double) RESOLUTION ; 
           //sine   = Math.round(Math.sin(theta*i)*RESOLUTION)/(double) RESOLUTION ; 
           //cosine = Math.round(Math.cos(theta*i)*RESOLUTION)/(double) RESOLUTION ; 
           System.out.printf(" (%3d/%3d)*2*PI: ",i, 24); 
           //System.out.print(sine+" ");
           //System.out.println(cosine); 
           System.out.printf("%10.5f ", sine); 
           System.out.printf("%10.5f%n",cosine);    
        }
    }   
}
