
/**
 * Write a description of class IndexedLoop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class IndexedLoop
{
    static String[] s = {"Uno", "Dos", "Tres", "Cuatro", "Cinco", 
                  "Seis", "Siete", "Ocho", "Nueve", "Diez"}; 
                
    public static void main(String[] args){
      for (int i=0; i< s.length; i++){
            System.out.println(s[i]); 
        }
    }
}
