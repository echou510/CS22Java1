import java.io.File; 
import java.io.PrintWriter; 
import java.io.IOException; 
/**
 * Write a description of class NASA here.
 * 
 * This program calculates the gravity of the 9 planets of solar system with the mass and the diameter 
 * information of the planets in Solar system.  (The table does not have pluto, but the assessment need 
 * 9 numbers. So, I add the pluto in.)
 * 
 * g = G * M / (radius**2)  // Equation used to calculate the gravity of the planets. 
 * 
 * The gravity data is written into an output file "gravity.txt".
 * 
 * New trials: 
 * try { // code block } catch (IOException e){ // code block for exception handling }
 * Javadoc documentation page is also generated using the toggle documentation view. 
 * 
 * @author (Eric Y. Chou) 
 * @version (06/04/2016)
 */
public class NASA
{
  /**
   * Calculate the gravity of planets with a mass array, and a diameter array.
   * 
   * @param mass       a double array for mass of planets.
   * @param diameter   a double array for diamter of planets.
   * @return gravity double data type.
   */
  public static double[] gravity(double[] mass, double[] diameter){
      final double G = 6.67*Math.pow(10, -11); // gravitational constant  6.674×10^−11 N⋅m^2/kg^2 
      double[] g = new double[mass.length];
      for(int i =0; i<mass.length; i++){       // calculation of gravity
          g[i] = G*mass[i]/(diameter[i]*diameter[i]/4);
      }
      return g;
  } // end of gravity
  
  /**
   * Print the planets' information to screen
   * 
   * @param gravity    a double array for gravity of planets.
   * @param mass       a double array for mass of planets.
   * @param diameter   a double array for diamter of planets.
   * @param names      the String array for the names of planets
   */
  public static void printScreen(double[] g, double[] mass, double[] diameter, String[] names) 
  {
    System.out.println("                 Planetary Data");
    System.out.printf("%8s ", "Planet");
    System.out.printf("%15s     ", "Diameter(km)");
    System.out.printf("%6s  ", "Mass(kg)");
    System.out.printf("%6s%n", "g(m/s^2)");
    System.out.println("-----------------------------------------------");
    //Print
    for(int i = 0; i<mass.length; i++){
        System.out.printf("%-8s ", names[i]);
        System.out.printf("%15.2f    ", diameter[i]/1000.0);
        System.out.printf("%6.3e ", mass[i]);
        System.out.printf("%6.2f%n", g[i]);
    }
  } // end of printScreen
  
  /**
   * Print the planets' information to a text file "gravity.txt"
   * 
   * @param gravity    a double array for gravity of planets.
   * @param mass       a double array for mass of planets.
   * @param diameter   a double array for diamter of planets.
   * @param names      the String array for the names of planets.
   * @throws IOException I/O file access failure exception. 
   */
  public static void printToFile(double[] g, double[] mass, double[] diameter, String[] names, String filename)
  throws IOException{   // print out the 9 planet's gravity number only.  The mass and Diameters are commented out
    File oFile = new File(filename); 
    PrintWriter out = new PrintWriter(oFile); 
    //Print
    for(int i = 0; i<mass.length; i++){
        out.printf("%6.2f%n", g[i]);
    }
    out.close(); 
  } // end of printToFile
        
  /** 
   * Main function for the application GravityV1.java
   * 
   * @param args argument list from console.
   */
  public static void main(String[] args){
    double[] mass = {3.30*Math.pow(10,23), 4.869*Math.pow(10,24), 5.9722*Math.pow(10,24), 6.4219*Math.pow(10,23), 
                     1.9*Math.pow(10,27), 5.68*Math.pow(10,26), 8.683*Math.pow(10,25), 1.0247*Math.pow(10,26), 1.27*Math.pow(10,22)};
    double[] diameter = {4880*1000.0, 12103.6*1000.0, 12756.3*1000.0, 6794*1000.0, 
                         142984*1000.0, 120536*1000.0, 51118*1000.0, 49532*1000.0, 2274*1000.0};// converted from km to meter.                      
    String[] names = {"Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto"};
    
    // calculation of gravity
    double[] g = gravity(mass, diameter); // array for gravity of planets
    
    // print to Screen 
    printScreen(g, mass, diameter, names); 
    
    // print to File with I/O Exception Handler
    try {
       printToFile(g, mass, diameter, names, "gravity.txt"); 
    }
    catch(IOException e){ System.out.println("Output File Access I/O Exception !!");
    }
  }
}
    