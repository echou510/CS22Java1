
/**
 * Write a description of class Stats01 here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 11/23/2015)
 */
public class Stats01
{   public static int max(int num1, int num2){
       int result=Integer.MIN_VALUE; 
       
       if (num1> num2) result = num1; 
       else result = num2; 
       
       return result; 
    }
    
       public static int min(int num1, int num2){
       int result=Integer.MAX_VALUE; 
       
       if (num1< num2) result = num1; 
       else result = num2; 
       
       return result; 
    }
    
    public static double sum(int num1, int num2){
       double result = 0.0; 
       
       result = num1 + num2;  
       
       return result; 
    }
    
    public static double avg(int num1, int num2){
       double result = 0.0; 
       
       result = (num1 + num2)/2.0;  
       
       return result; 
    } 
    
   public static int max3(int num1, int num2, int num3){
       int result=Integer.MIN_VALUE; 
       
       if (num1> num2) {
           if (num1 > num3) result = num1; 
           else result = num3; 
        } 
       else if (num2>num3) result = num2; 
            else result = num3; 
       
       return result; 
    }
    
       public static int min3(int num1, int num2, int num3){
       int result=Integer.MAX_VALUE; 
       
       if (num1< num2) {
           if (num1 < num3) result = num1; 
           else result = num3; 
        } 
       else if (num2<num3) result = num2; 
            else result = num3;   
       
       return result; 
    }
    
    public static double sum3(int num1, int num2, int num3){
       double result = 0.0; 
       
       result = num1 + num2 + num3;  
       
       return result; 
    }
    
    public static double avg3(int num1, int num2, int num3){
       double result = 0.0; 
       
       result = (num1 + num2 + num3)/3.0;  
       
       return result; 
    }     
    
    public static int max4(int num1, int num2, int num3, int num4){ // single elimination
       
       int a1 = max(num1, num2); 
       int a2 = max(num3, num4); 
       int a3 = max(a1, a2); 
       
       return a3; 
    }  
    
    public static int max5(int num1, int num2, int num3, int num4, int num5){ // single elimination
       
       int a1 = max(num1, num2); 
       int a2 = max(num3, num4);
       int a3 = max(a2, num5); 
       int a4 = max(a1, a3); 
       
       return a4; 
    }  
    
    public static void main(String[] args){
      int i = 5; 
      int j = 2; 
      int k = 14; 
      int p = 4; 
      int q = 29; 
      System.out.println("Two Variables: "); 
      System.out.println("Maximum of "+i+" and "+j+" is "+max(i,j)); 
      System.out.println("Minimum of "+i+" and "+j+" is "+min(i,j)); 
      System.out.println("Sum of "+i+" and "+j+" is "+sum(i,j)); 
      System.out.println("Average of "+i+" and "+j+" is "+avg(i,j));
      System.out.println(); 
      System.out.println("Three Variables: "); 
      System.out.println("Maximum of "+i+" and "+j+" and "+k+" is "+max3(i,j,k)); 
      System.out.println("Minimum of "+i+" and "+j+" and "+k+" is "+min3(i,j,k)); 
      System.out.println("Sum of "+i+" and "+j+" and "+k+" is "+sum3(i,j,k)); 
      System.out.println("Average of "+i+" and "+j+" and "+k+" is "+avg3(i,j,k));   
      System.out.println(); 
      System.out.println("Four Variables: (max only) Single Elimination...");
      System.out.println("Maximum of "+i+" and "+j+" and "+k+" and "+p+" is "+max4(i,j,k,p));       
      System.out.println(); 
      System.out.println("Five Variables: (max only) Single Elimination...");
      System.out.println("Maximum of "+i+" and "+j+" and "+k+" and "+p+" and "+q+" is "+max5(i,j,k,p,q));       
      System.out.println();       
    }
}
