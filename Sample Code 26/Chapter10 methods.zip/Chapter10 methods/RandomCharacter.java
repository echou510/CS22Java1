
/**
 * Write a description of class RandomCharacter here.
 * 
 * @author (Eric Y. Chou) 
 * @version (11/26/2015)
 */
public class RandomCharacter
{
   	 /** Generate a random character between ch1 and ch2 */
	  public static char getRandomCharacter(char ch1, char ch2) {
	    return (char)(Math.random() * (ch2 - ch1 + 1) + ch1);
	  }

	  /** Generate a random lowercase letter */
	  public static char getRandomLowerCaseLetter() {
	    return getRandomCharacter('a', 'z');
	  }

	  /** Generate a random uppercase letter */
	  public static char getRandomUpperCaseLetter() {
	    return getRandomCharacter('A', 'Z');
	  }

	  /** Generate a random digit character */
	  public static char getRandomDigitCharacter() {
	    return getRandomCharacter('0', '9');
	  }

	  /** Generate a random character */
	  public static char getRandomCharacter() {
	    return getRandomCharacter('\u0000', '\uFFFF');
	  }
	  
	  /** Generate a random symbol in region 1 ASCII: 33-47*/
	  public static char getRandomSymbolRegion1(){
	    return getRandomCharacter('!', '/');
	   }
	   
	  /** Generate a random symbol in region 2 ASCII: 58-64*/
	  public static char getRandomSymbolRegion2(){
	    return getRandomCharacter(':', '@');
	   }
	   
	  /** Generate a random symbol in region 3 ASCII: 91-96*/
	  public static char getRandomSymbolRegion3(){
	    return getRandomCharacter('[', '\'');
	   }
	   
	  /** Generate a random symbol in region 4 ASCII: 123-126*/
	  public static char getRandomSymbolRegion4(){
	    return getRandomCharacter('{', '~');
	   }
	   
	  /** Generate a random symbol or punctuation mark */
	  public static char getRandomPunctuationMarkAndSymbol(){
	      int punc = ((int) (Math.random()*32));     // create a punctuation index from 1 to 17
	      char passPunc = '!'; 
              if (punc < 15) { passPunc = getRandomSymbolRegion1(); }                        // region 1 for punctuation 33 - 47
              else if (punc >= 15 && punc < 22) { passPunc = getRandomSymbolRegion2(); }     // region 2 for punctuation 58 - 64
              else if (punc >=22 && punc < 28) { passPunc = getRandomSymbolRegion3(); }  // region 3 for punctuation 91 - 96
              else { passPunc = getRandomSymbolRegion4(); } 
          return passPunc; 
	   }
}
