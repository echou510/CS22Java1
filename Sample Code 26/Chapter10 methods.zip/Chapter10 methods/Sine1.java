
/**
 * Write a description of class Sine1 here.
 * 1.This program is created to calculate the Y values of a circle with a radius of 1.0  
 *   and to print them out neatly. And, create a table for unit circle. 
 * 2.By using the printf formatted output and a for loop, you can use them to create this program.
 * 
 * 3.I also try to make the step_size of 0.1, 0.01, 0.001 works as suggested on the assessment instruction. 
 * 
 * @author (Eric Y. Chou) 
 * @version (06/04/2016)
 */
public class Sine1
{
   public static void main(String[] args){
    //Variables
    double radius = 1.0;
    final double ACCURACY = 1000000.0;  // more digits, more accuracy used. This is used for numerical error setting. 
    // step_size adjustments (0.1, 0.01, 0.001, 0.0001, 0.00001 are supported) 
    final double STEP_SIZE = 0.1;      // constant used to update step_size easier, such as 0.01, 0.001
    String outputFormat = ""; 
    if      (STEP_SIZE == 0.1)   outputFormat = "   %8.2f";  // adjusting the bits to get the best results
    else if (STEP_SIZE == 0.01)  outputFormat = "   %8.2f";
    else if (STEP_SIZE == 0.001) outputFormat = "   %8.3f";
    else outputFormat = "   %8.5f"; 
    
    // variables for data points
    double x  = 0.0;              // x variable
    double y  = 0.0;              // top half y and lower half y (y2)
    double y2 = 0.0;
        
    //Printing Information
    System.out.println("      Points on a Circle of Radius "+ radius);
    System.out.printf("   %8s", "x1");
    System.out.printf("   %8s", "y1");
    System.out.printf("   %8s", "x1");
    System.out.printf("   %8s", "y2");
    System.out.println();
    System.out.println("----------------------------------------------");
    //For loop to calculate the y values
    for (x = 1.0*radius; x >= -1.0*radius; x = x-STEP_SIZE)
      {  y = Math.sqrt(Math.pow(radius, 2.0) - Math.pow(x, 2.0));   // y value for upper half circle
         y2 = y * -1.0;                                             // y value for lower half circle
         x = Math.round(x *  ACCURACY)/(double) ACCURACY;           // quantized with 6-digit accuracy only for x, make sure x does not run into 
                                                                    // double data type numerical minor errors due to x=x-STEP_SIZE operations. 
                                                                    // -1.000 may sometimes does not show up if doesn't have this statement.
         System.out.printf(outputFormat, x);                        // 8.3f format used to make sure STEP_SIZE = 0.001 still works in proper format. 
         System.out.printf(outputFormat, y);
         System.out.printf(outputFormat, x);
         System.out.printf(outputFormat+"%n", y2);
      }
    }
}
