
/**
 * Write a description of class Increase here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 11/23/2015)
 */
public class Increase
{
   public static void main(String[] args) {
       int x = 1;
       System.out.println("Before the call, x (x in main)is " + x);
       increase(x);
       System.out.println("after the call, x (x in main after increase) is " + x);
    }

   public static void increase(int n) {
	n++;
        System.out.println("n inside the method is " + n);
   }
}
