import javax.swing.JPanel; 
import java.awt.Graphics;
import javax.swing.JFrame;
/**
 * Write a description of class SierpinskiTriangleS here.
 * 
 * @author (Eric Y. Chou) 
 * @version (03/03/2016)
 */
public class SierpinskiTriangleS extends JPanel
{
    public void drawSierpinskiTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int level, Graphics canvas)
    {
        if(((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) > 3 && level >0)
        {
            canvas.drawLine(x1,y1,x2,y2); 
            canvas.drawLine(x2,y2,x3,y3);
            canvas.drawLine(x3,y3,x1,y1);
            
            drawSierpinskiTriangle((x1+x2)/2, (y1+y2)/2, (x1+x3)/2, (y1+y3)/2, x1, y1, level-1, canvas);
            drawSierpinskiTriangle((x1+x2)/2, (y1+y2)/2, (x3+x2)/2, (y3+y2)/2, x2, y2, level-1, canvas);
            drawSierpinskiTriangle((x1+x3)/2, (y1+y3)/2, (x3+x2)/2, (y3+y2)/2, x3, y3, level-1, canvas);
            //drawSierpinskiTriangle((x1+x2)/2, (y1+y2)/2, (x1+x3)/2, (y1+y3)/2, (x2+x3)/2, (y2+y3)/2, canvas);
        }
    }
    
    public void paint(Graphics g)
    {
        drawSierpinskiTriangle(10, 280, 290, 280, 150, 40,5, g);
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("My Drawing");
        JPanel canvas = new SierpinskiTriangleS();
        canvas.setSize(400, 400);
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
