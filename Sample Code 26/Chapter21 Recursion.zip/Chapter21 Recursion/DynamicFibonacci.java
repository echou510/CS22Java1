
public class DynamicFibonacci
{
    public static int fibo(int n){
        if (n==0) return 0; 
        if (n==1) return 1; 
        return fibo(n, 2, 1, 0); 
    }
    public static int fibo(int n, int i, int f1, int f2){
       if (n==i) return f1 + f2; 
       return fibo(n, i+1, f1+f2, f1); 
    }
    
    public static void main(String[] args){
       for (int i=0; i<20; i++){
           System.out.printf("fibo(%d) = %d\n", i, fibo(i)); 
        }
    }
}
