public class RecursiveProduct
{
    public static int product(int n){
      if (n==0) return 1; 
      return product(n-1)*n; 
    }
    
    public static void main(String[] args){
      System.out.print("\f");
      System.out.println(product(5)); 
    }
}
