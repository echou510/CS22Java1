public class RecursiveSum
{
    public static int sum(int n){
      if (n==0) return 0; 
      return sum(n-1)+n; 
    }
    
    public static void main(String[] args){
      System.out.print("\f");
      System.out.println(sum(10)); 
    }
}