
/**
 * Write a description of class RecursivePalindrome here.
 * 
 * This is the Palindrome class.
 * It has the functions that help the tester class see whether or not the word entered is a palindrome or not.
 * @author (Eric Y. Chou) 
 * @version (06/06/2016)
 */
public class Palindrome
{
    //helper function
    public String helper(String s){
        s = s.toLowerCase();
        String result = "";
        //int j = 0;
        //for loop
        for(int i = 0; i < s.length(); i++ ){
            if(Character.isDigit(s.charAt(i))|| Character.isLetter(s.charAt(i)))result += s.charAt(i);
        }
        return result;
    }
    
    //isPalindrome function
    public boolean isPalindrome(String s){
        s = helper(s);
        // if loop
        if(s.length()== 0)return true;
        if(s.length()== 1)return true;
        if(s.length()== 2)return s.charAt(0)== s.charAt(1);
        return (s.charAt(0)== s.charAt(s.length()-1))&& isPalindrome(s.substring(1, s.length()-1));
    }
  
}
