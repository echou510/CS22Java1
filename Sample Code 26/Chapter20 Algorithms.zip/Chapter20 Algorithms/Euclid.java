
import java.util.Scanner; 
/**
 * Write a description of class Euclid here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Euclid {

    // recursive implementation
    public static int gcd(int p, int q) {
        if (q == 0) return p;
        else return gcd(q, p % q);
    }

    // non-recursive implementation
    public static int gcd2(int p, int q) {
        while (q != 0) {
            int temp = q;
            q = p % q;
            p = temp;
        }
        return p;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); 
        System.out.print("Enter first  number: "); 
        int p = input.nextInt();
        System.out.print("Enter second number: "); 
        int q = input.nextInt();
        int d  = gcd(p, q);
        int d2 = gcd2(p, q);
        System.out.println("Recursive gcd(" + p + ", " + q + ") = " + d);
        System.out.println("Iterative gcd(" + p + ", " + q + ") = " + d2);
    }
}