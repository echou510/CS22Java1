package StandardArray;

import java.util.Arrays; 
/**
 * Write a description of class Merge here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/29/2016)
 */
public class Merge
{
   static int[] a = {1, 3, 5, 7, 9};
   static int[] b = {0, 2, 4, 6, 8};
   public static int[] merge(int[] a, int[] b){
       int[] r = new int[a.length+b.length]; 
       int p1=0; 
       int p2=0; 
       int p3=0; 
       while (p1<a.length && p2<b.length){
           if (a[p1]<=b[p2]){
               r[p3++]=a[p1++];
            }
           else {
               r[p3++]=b[p2++];
            }
        }
       while (p1<a.length) r[p3++]=a[p1++];
       while (p2<b.length) r[p3++]=b[p2++];
       
       return r; 
    }
    
   public static void main(String[] args){
       Integer[] aa = new Integer[a.length]; for (int i=0; i<a.length; i++) aa[i]=a[i]; 
       Integer[] bb = new Integer[b.length]; for (int i=0; i<b.length; i++) bb[i]=b[i];
       System.out.println("A[]="+Arrays.asList(aa));  
       System.out.println("B[]="+Arrays.asList(bb));
       int[] r = merge(a, b);
       Integer[]rr = new Integer[r.length]; for (int i=0; i<r.length; i++) rr[i]=r[i];
       System.out.println("R[]="+Arrays.asList(rr));
    }
}
