package StandardArray;


/**
 * Write a description of class TwoDTo1D here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TwoDTo1D
{
    public static int[] a = new int[15];
    public static int[][] m = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {9, 10, 11}}; 
    
    public static void printArray(int[] a){
        for (int i=0; i<a.length; i++){
           System.out.print(a[i]+" "); 
        }
        System.out.println(); 
    } 
    public static void print2DArray(int[][] m){
        for (int i=0; i<m.length; i++){
           for (int j=0; j<m[0].length; j++){
               System.out.print(m[i][j]+" "); 
           }
           System.out.println(); 
        }
        System.out.println(); 
    }  
    
    public static void convert2DTo1D(){
        int k =0; 
        for (int i=0; i<m.length; i++) {
           for (int j=0; j<m[0].length && k<a.length; j++){
              a[k]=m[i][j];
              k++; 
            }
        }  
    }
    
    public static void main(String[] args){
        System.out.println("Initial Condition:"); 
        System.out.print("1-D A[0..9]= "); printArray(a); 
        System.out.println("2-D M[0..3][0..2]="); print2DArray(m); 

        convert2DTo1D(); 
        
        System.out.println("\n\nFinal Condition:"); 
        System.out.print("1-D A[0..9]= "); printArray(a); 
        System.out.println("2-D M[0..3][0..2]="); print2DArray(m);         

    }  
}
