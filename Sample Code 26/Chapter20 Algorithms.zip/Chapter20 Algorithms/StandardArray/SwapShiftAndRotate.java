package StandardArray;

import java.util.List; 
import java.util.ArrayList; 
import java.util.Arrays; 
/**
 * Swap, Shift and Rotate (including random shuffle)
 * 
 */
public class SwapShiftAndRotate
{
    static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    static Integer[] b = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};// Integer in wrapper type
    static int[][] m = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    static ArrayList<Integer> blist = new ArrayList<Integer>(); 
    
    public static void swapArray(int[] a, int i, int j){
        int temp = a[i]; 
            a[i] = a[j]; 
            a[j] = temp;           
    }
    
    public static void swapArrayList(ArrayList<Integer> a, int i, int j){
          Integer xi = a.get(i); 
          a.add(j, xi); 
          Integer xj = a.remove(j+1); 
          a.add(i, xj); 
          a.remove(i+1); 
    }
    
    public static void reset(){
        a = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        b = new Integer[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        blist = new ArrayList<Integer>(); 
        for (Integer bx: b){ blist.add(bx); }
    }
    
    public static void rShiftArray(int[] a){
       int temp = a[a.length-1]; 
       for (int i=a.length-2; i>=0; i--){
            a[i+1] = a[i];
        }
        
       a[0] = temp;  // don't put it back if it is shifting but not rotating
    } 
    
    public static void rShiftArrayList(ArrayList<Integer> a){
         Integer temp = a.remove(a.size()-1);
         a.add(0, temp);  // don't put it back if it is shifting but not rotating
    }
    
    public static void lShiftArray(int[] a){
       int temp = a[0]; 
       for (int i=1; i<a.length; i++){
            a[i-1] = a[i];
        }
        
       a[a.length-1] = temp;  // don't put it back if it is shifting but not rotating
    }
    
    public static void lShiftArrayList(ArrayList<Integer> a){
         Integer temp = a.remove(0);
         a.add(temp);  // don't put it back if it is shifting but not rotating
    }
    
    public static void shuffleArray(int[] a){
       for (int i=0; i<a.length; i++){
           int j = (int) (Math.random()*a.length); 
           swapArray(a, i, j); 
        }
    }
    
    public static void shuffleArrayList(ArrayList<Integer> a){
       for (int i=0; i<a.size(); i++){
           int j = (int) (Math.random()*a.size()); 
           swapArrayList(a, i, j); 
        }
    } 
    
    public static void main(String[] args){
          reset(); 
          swapArray(a, 3, 5); 
          System.out.println("Array Swap(3, 5)="+Arrays.toString(a));
          swapArrayList(blist, 3, 5);
          System.out.println("ArrayList Swap(3, 5)="+blist);
          reset(); 
          rShiftArray(a); 
          System.out.println("Array Rshift="+Arrays.toString(a));
          rShiftArrayList(blist); 
          System.out.println("ArrayList Rshift="+blist);
          reset(); 
          lShiftArray(a); 
          System.out.println("Array Rshift="+Arrays.toString(a));
          lShiftArrayList(blist); 
          System.out.println("ArrayList Rshift="+blist);
          reset();
          shuffleArray(a); 
          shuffleArrayList(blist); 
          System.out.println("Array Shufflet="+Arrays.toString(a));
          System.out.println("ArrayList Shuffle="+blist);
    }
}
