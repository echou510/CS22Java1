package StandardArray;

import java.util.Arrays; 
/**
 * Write a description of class Delete here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/29/2016)
 */
public class Delete
{
   static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
   
   static int[] delete(int[] a, int k){
        if (k<0 || k>=a.length) return a; 
        int[] r = new int[a.length-1];
        
        for (int i=0; i<k; i++){ r[i] = a[i]; }
        for (int i=k; i<r.length; i++) r[i] = a[i+1]; 
        
        return r; 
    }
    
   public static void main(String[] args){
      Integer[] aa = new Integer[a.length]; for (int i=0; i<a.length; i++) aa[i] = a[i];
      System.out.println("Original Array="+Arrays.asList(aa)); 
      int[] r = delete(a, 6); 
      Integer[] rr = new Integer[r.length]; for (int i=0; i<r.length; i++) rr[i] = r[i]; 
      System.out.println("After deletion "+" Array="+Arrays.asList(rr)); 
    }
}
