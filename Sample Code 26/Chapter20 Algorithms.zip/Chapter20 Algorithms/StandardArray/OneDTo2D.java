package StandardArray;


/**
 * Write a description of class OneDTo2D here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OneDTo2D
{
   public static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
   public static int[][] m = new int[4][3]; 
    
    public static void printArray(int[] a){
        for (int i=0; i<a.length; i++){
           System.out.print(a[i]+" "); 
        }
        System.out.println(); 
    } 
    public static void print2DArray(int[][] m){
        for (int i=0; i<m.length; i++){
           for (int j=0; j<m[0].length; j++){
               System.out.print(m[i][j]+" "); 
           }
           System.out.println(); 
        }
        System.out.println(); 
    }  
    
    public static void convert1DTo2D(){
        int k =0; 
        for (int i=0; i<m.length; i++) {
           for (int j=0; j<m[0].length && k<a.length; j++){
              m[i][j] = a[k];
              k++; 
            }
        }  
    }
    
    public static void main(String[] args){
        System.out.println("Initial Condition:"); 
        System.out.print("1-D A[0..9]= "); printArray(a); 
        System.out.println("2-D M[0..3][0..2]="); print2DArray(m); 
        convert1DTo2D(); 
        
        System.out.println("\n\nFinal Condition:"); 
        System.out.print("1-D A[0..9]= "); printArray(a); 
        System.out.println("2-D M[0..3][0..2]="); print2DArray(m);         

    }
}
