import java.util.Random;
import java.util.Scanner;
/**
 * Write a description of class TwoDice here.
 * 
 * @author (Eric Y. Chou) 
 * @version (11/22/2015)
 */
public class TwoDice
{
    public static void main(String[] args){
     long seed = System.currentTimeMillis();
     // Declare and initialize variables and objects
     Scanner input = new Scanner(System.in); 
     Random randNum = new Random(seed);
     int match = 0;             // number of match for a certain combination of die
     double prob = 0.0;         // probability of the match for a certain combination of die
     int die1, die2; 
       
     //Print heading for output table
     System.out.println("********************************************************************************"); 
     System.out.println("Two Dice Game:"); 
     System.out.println(" Using nested loops, iterates through the possible sums of the dice.");
     System.out.println(" Roll the dice the given number of times for each sum.");
     System.out.println(" Count how many times the sum of the dice match the current sum being looked for.");
     System.out.println("********************************************************************************");
     
     //User Input: ask user for number of rolls and number of sides on a die
     System.out.print("Please enter the number of Rolls: ");
     int rolls = Integer.parseInt(input.nextLine());
     System.out.print("Please enter the number of sides on a die: "); 
     int sides = Integer.parseInt(input.nextLine());
     
     // Output Heading (not in the loop)
     System.out.println("Sum of Dice     Probability");
     //Probability of each combination of dice
     //Loop to increment through the possible sums of the dice 
     for (int sum = 2;  sum <= sides*2; sum++){ // each iteration for one sum of possible combinations
        match = 0;   // reset match number for the next combination of dice. 
         //Loop to throw dice given number of times
        for (int rr=0; rr<rolls; rr++){ // each iteration for one roll of two dice
              //Randomly generate values for two dice 
              die1 = (int)(randNum.nextDouble()*sides)+1;
              die2 = (int)(randNum.nextDouble()*sides)+1;
              //Check if the sum of dice is equal to the given sum
              if ((die1+die2) == sum) match++; 
            } // end of rolls loop
        //After all throws, calculate percentage of throws that resulted in the given sum
        prob = (double) match/rolls;  
        //Print results	       
        System.out.printf("%4d", sum); 
        System.out.print("s:        "); 
        System.out.printf("%10.3f",prob*100.0);
        System.out.println("%"); 
     } // end of sum loop
  } // end of main
}
