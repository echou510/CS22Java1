import java.util.Scanner; 
/**
 * Write a description of class ReverseOfStrings here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ReverseOfStrings
{
   public static String reverse(String in){
       String out = ""; 
       while (in.length()!=0){
           out = in.substring(0, 1)+out; 
           in = in.substring(1); 
        }
       return out; 
    }
    
   public static void main(String[] args){
       System.out.print("\f");
       Scanner input = new Scanner(System.in); 
       System.out.print("Enter a string: "); 
       String a = input.nextLine(); 
       System.out.println("It's reverse is "+reverse(a)); 
    }
}
