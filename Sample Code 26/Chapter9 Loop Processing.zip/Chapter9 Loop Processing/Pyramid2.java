
/**
 * Write a description of class Pyramid2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Pyramid2 {
    public static void main(String[] args) {
        for (int i = 5; i >= 0; i--) {
            for (int s = 1; s < i; s++) {
                System.out.print(" ");
            }
            for (int j = 5; j >= i; j--) {
                System.out.print("#");
            }
            System.out.println("");
        }
    }
}