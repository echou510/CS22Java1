import java.util.Scanner; 
/**
 * Write a description of class SumOfDigits here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SumOfDigits
{
   public static int sumOfDigits(int d){
      if (d==0) return 0; 
      int sum = 0; 
      while (d>0){
          int x = d % 10; 
          sum += x; 
          d /= 10; 
        }
      return sum; 
    }
    public static void main(String[] args){
      System.out.print("\f");
      
      System.out.print("Enter a Decimal Integer: ");
      Scanner input = new Scanner(System.in); 
      int dec = input.nextInt(); 
      int sum = sumOfDigits(dec); 
      System.out.printf("%d's sum of the digits is %s%n", dec, sum); 
    }
}
