import java.util.ArrayList; 
public class TwoWayRemove1
{
  public static void main(String[] args){
      ArrayList<Integer> numbers = new ArrayList<Integer>(); 
      numbers.add(1); numbers.add(2); numbers.add(3); 
      System.out.println("ArrayList contains: "+numbers); 
      numbers.remove(1); numbers.remove(3); 
      // 3 is int type, this will cause exception
    }
}
