import java.util.Scanner; 
import java.util.ArrayList; 
/**
 * Write a description of class ArrayListProcessingIArrayProcessing here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/05/2015)
 */
public class ArrayListProcessingIArrayProcessing
{
    //static double[] myList = {1.0, 2.0, 3.0, 4.0, 5.0}; 
    static ArrayList<Double> myList1 = new ArrayList<Double>();
    public static void ap1_Initialize(){
           Scanner input = new Scanner(System.in); 
          
           System.out.print("Enter " + /* myList.length */ 5 + " values: ");
            
           //for (int i = 0; i < myList.length; i++) 
           for (int i=0; i<5; i++)
              // myList[i] = input.nextDouble();
              myList1.add(input.nextDouble()); 
    }
    
    public static void ap2_random(){
           int myList1Length = myList1.size(); 
           myList1.clear(); 
           //for (int i = 0; i < myList.length; i++) {
             for (int i = 0; i< myList1Length; i++){
              //myList[i] = Math.random() * 100;
              myList1.add(Math.random() * 100); 
           }
    }
    
    public static void ap3_printArrayList(){
        //for (int i = 0; i < myList.length; i++) {
        //    System.out.printf("%8.2f ", myList[i]);
        //}
        
        // Adjust precision for the myList1 arraylist to make sure it is user-friendly
        for (int i=0; i<myList1.size(); i++){
           myList1.set(i, (int) (myList1.get(i).doubleValue()*100)/100.0); 
        }
        System.out.println(myList1);
    }
    
    public static double ap4_sum(){
        double total = 0;
        //for (int i = 0; i < myList.length; i++) {
        //total += myList[i];
        //}
        for (int i=0; i<myList1.size(); i++){
           total += myList1.get(i).doubleValue(); 
        }
        return total; 
    }
    
    public static double ap5_max(){
       //double max = myList[0];
       // for (int i = 1; i < myList.length; i++) {
       //   if (myList[i] > max) max = myList[i];
       // }
        double max = Double.MIN_VALUE; 
        for (int i = 0;i< myList1.size(); i++){
            if (myList1.get(i).doubleValue() > max) max = myList1.get(i).doubleValue(); 
        }
        return max; 
    }
    public static int ap6_indexMax(){
       //double max = myList[0];
       // for (int i = 1; i < myList.length; i++) {
       //   if (myList[i] > max) max = myList[i];
       // }
        double max = Double.MIN_VALUE; 
        int maxi = Integer.MIN_VALUE;
        for (int i = 0;i< myList1.size(); i++){
            if (myList1.get(i).doubleValue() > max){
                max = myList1.get(i).doubleValue(); 
                maxi = i; 
            }
        }
        return maxi; 
    }
    
    public static void ap7_randomShuffle(){
        //for (int i = 0; i < myList.length; i++) {
        for (int i=0; i<myList1.size(); i++){
           // Generate an index j randomly
           //int index = (int)(Math.random()* myList.length);
           int index = (int)(Math.random()* myList1.size());
 
           // Swap myList[i] with myList[index]
           //double temp = myList[i];
           //  myList[i] = myList[index]; 
           //  myList[index] = temp;
           
           // Swap myList1.get(i) and myList1.get(index)
           double temp = myList1.get(i); // already Double wrapper type, no need to convert to double 
           myList1.set(i, myList1.get(index)); 
           myList1.set(index, temp); 
        }
    }
    public static void ap8_leftShifting(){
       //double temp = myList[0]; // Retain the first element
       double temp = myList1.get(0); 
       
       // Shift elements left
       //for (int i = 1; i < myList.length; i++) {
       for (int i=1; i<myList1.size(); i++){
          //myList[i - 1] = myList[i];
          myList1.set(i-1, myList1.get(i)); 
       }

       // Move the first element to fill in the last position
       //myList[myList.length - 1] = temp;
       myList1.set(myList1.size()-1, temp); 
    }
    
    public static void ap9_rightShifting(){
        //double temp = myList[myList.length-1]; // Retain the last element
        double temp = myList1.get(myList1.size()-1); 

        // Shift elements left
        //for (int i = myList.length-2; i >=0; i--) {
        for (int i=myList1.size()-2; i>=0; i--){
            //myList[i + 1] = myList[i];
            myList1.set(i+1, myList1.get(i)); 
        }

        // Move the last element to fill in the first position
        //myList[0] = temp;
        myList1.set(0, temp); 
    }
    
    public static void main(String[] args){
        // demo example 1 and example 3: 
        ap1_Initialize(); 
        System.out.print("Array After Initialization: "); 
        ap3_printArrayList(); 
        System.out.println(); 
        
        // demo example 2
        ap2_random(); 
        System.out.print("Array After Random Input: "); 
        ap3_printArrayList(); 
        System.out.println(); 
        
        // demo exmple 4: 
        System.out.printf("Sum of myList: %10.4f %n", ap4_sum()); 
        // demo exmple 5: 
        System.out.printf("max of myList: %10.4f %n", ap5_max()); 
       // demo exmple 6: 
        System.out.printf("Index %3d has the max of myList: %10.4f %n", ap6_indexMax(), ap5_max()); 
        // demo exmple 7: 
        System.out.print("After Random Shuffle: ");
        ap7_randomShuffle(); 
        ap3_printArrayList(); 
        System.out.println(); 
        // demo example 8: 
        System.out.print("After Left Shifting: ");
        ap8_leftShifting(); 
        ap3_printArrayList(); 
        System.out.println(); 
        
        // demo example 9: 
        System.out.print("After Right Shifting: ");
        ap9_rightShifting(); 
        ap3_printArrayList(); 
        System.out.println(); 
    }
}
