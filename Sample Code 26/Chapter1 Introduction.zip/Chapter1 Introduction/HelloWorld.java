
/**
 * Write a description of class HelloWorld here.
 * 
 * First program for me. 
 * 
 * slash with 2 star at the beginning of a comment line means a comment 
 * for Javadoc to extract
 * 
 * @author (Eric Y. Chou) 
 * @version (V1.0, 10/29/2015)
 */
public class HelloWorld
{   /* I am very very happy. 
    
       How do you do? 
    */
    public static void main(String[] args){
        System.out.println("Hello World !"); // This line is voided after this. 
    } // end of main method 
} // end of class 
