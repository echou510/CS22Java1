
/**
 * Write a description of class YESNOHappy here.
 * 
 * Demo the concept of boolean value and boolean expression. 
 * 
 * Demo char primitive data type and char arithmetic
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 11/08/2015)
 */
public class YESNOHappy
{    
   public static void main(String[] args){
     // YES constant
     final boolean YES = true; 
     
     // NO constant 
     final boolean NO = false; 
     
     // Happy Characters: ch0, ch1, ch2, ch3, ch4, ch5; 
     char ch0 = 'H';
     char ch1 = 'a';
     char ch2 = 'p';
     char ch3 = 'p';
     char ch4 = 'y';
     char ch5 = '!';
     
     // print The boolean value of YES and NO
     System.out.println("Boolean Value of YES: " + YES + "    Boolean Value of NO: " + NO); 
     
     // if (YES) print ""+(ch0)+(ch1) 
     if (YES) {
        System.out.println("Yes case: "+(ch0)+(ch1)); 
     }
     // if (NO) print ""+ch2+ch3
     if (!NO) System.out.println("No case: "+ch2+ch3); 
     
     // if (YES && Character.isLetter(ch0)) print ""+ch0+ch1+ch2+ch3+ch4+ch5
     if (YES && Character.isLetter(ch0)){
        System.out.println("Original Message: "+(ch0)+ch1+ch2+ch3+(ch4)+ch5); 
     }
    
     // print "" + (ch0+1) + (ch1+1) + (ch2+1) + (ch3+1) + (ch4+1) + (ch5+1); 
     System.out.println("After Increment: " + (++ch0) + (++ch1) + (++ch2) + (++ch3) + (++ch4) + (++ch5)); 
     // print "" + (ch0-1) + (ch1-1) + (ch2-1) + (ch3-1) + (ch4-1) + (ch5-1); 
     System.out.println("After Decrement: " + (--ch0) + (--ch1) + (--ch2) + (--ch3) + (--ch4) + (--ch5)); 
   }
}
