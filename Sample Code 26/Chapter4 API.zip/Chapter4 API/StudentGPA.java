
// import the Scanner class here

/**
 * Write a description of class StudentGPA here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StudentGPA
{
    public static void main(String[] args){
    
        // Define the Scanner input stream 
        
        
        // Ask user to enter name, social security number (SSN), date of birth (DOB), 
        // address, 
        // math, eng, phy, chem, pe, ushistory score in number grade 0 to 5 in integer grade. 
        // Notice: make sure full name can be entered and there is no feed-through problem. 
        
        
        // Calculate the GPA for the student
        
        
        // print out student semeter report
        // 1. print a school score report head
        
        
        
        // 2. print the student name, 
        //    SSN in (XXX-XX-1234 format, only show the last 4 digits for security purpose),
        //    DOB,
        //    address
        
        
        // 3. print the digital score subject by subject
        
        
        // 4. print out the GPA 
               
 
    }
}
