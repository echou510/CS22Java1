import java.util.Arrays; 
public class ArraySet
{
    public static int[] ary = {8, 6, 5, 3, 6, 7, 7, 4, 4, 5, 3, 1, 9, 0, 6, 6};
    
    public static void printArray(int[] a, int n){
      System.out.print("[");
      for (int i=0; i<n; i++){
          if (i==0) System.out.print(a[i]);
          else System.out.print(", "+a[i]); 
        }
      System.out.println("]"); 
    }
    public static void main(String[] args){
       System.out.print("\f"); 
       int len = ary.length; 
       int top = 0; 
       int[] occurrence = new int[len];
       int[] set = new int[len]; 
       
       for (int i=0; i<ary.length; i++){
           boolean found = false; 
           for (int j=0; j<top; j++){
               if (set[j]==ary[i]) { 
                   found = true;
                   occurrence[j]++; 
                }
            }
           if (!found){
               set[top] = ary[i]; 
               occurrence[top] = 1; 
               top++; 
            }
        }
       
       System.out.print("Source Array: "); 
       printArray(ary, ary.length); 
       System.out.print("Set Array:        ");
       printArray(set, top); 
       System.out.print("Occurrence Array: ");
       printArray(occurrence, top); 
    }
}
