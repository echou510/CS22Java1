/**
 * Write a description of class Range here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Range
{      
    /**
     * rangeIn method: index generation method for for-each loop. 
     * 
     * This method can be a good workaround for for-each loop which has no built-in indice. 
     * 
     */
    public static int[] range(int begin, int end, int step){ // create a range in (data set) function 
        final int PRECISION = 100000; 
        int span = (end-begin)>=0 ? (end-begin+step-1) : (begin-end-step-1); 
        if (span <= 0) return null; 
        int count = Math.round(Math.abs(span/step)*PRECISION)/PRECISION; 
        
        int[] rangeList = new int[count]; 
        
        for (int i=0; i<count; i++){ rangeList[i] = begin + i * step; }
       
        return rangeList; 
    }  /* Wrong index will create run-time error */ 
    
    public static int[] range(int begin, int end){ // create a range in (data set) function 
        final int step = (end-begin)>=0 ? 1 : -1; 
        final int PRECISION = 100000; 
        int span = (end-begin)>=0 ? (end-begin+step-1) : (begin-end-step-1); 
        if (span <= 0) return null; 
        int count = Math.round(Math.abs(span/step)*PRECISION)/PRECISION; 
        
        int[] rangeList = new int[count]; 
        
        for (int i=0; i<count; i++){ rangeList[i] = begin + i * step; }
       
        return rangeList; 
    }  /* Wrong index will create run-time error */ 
    
    public static int[] range(int end){ // create a range in (data set) function 
        final int begin = 0; 
        final int step = (end-begin)>=0 ? 1 : -1; 
        final int PRECISION = 100000; 
        int span = (end-begin)>=0 ? (end-begin+step-1) : (begin-end-step-1); 
        if (span <= 0) return null; 
        int count = Math.round(Math.abs(span/step)*PRECISION)/PRECISION; 
        
        int[] rangeList = new int[count]; 
        
        for (int i=0; i<count; i++){ rangeList[i] = begin + i * step; }
       
        return rangeList; 
    }  /* Wrong index will create run-time error */ 
    public static void printIntArray(int[] myList){
        for (int e: myList) System.out.printf("%d ", e);
        System.out.println(); 
    }
    public static void main(String[] args){
       System.out.println("\f// Using rangeIn as index"); 
       int[] list2 = range(1, 32, 3); 
       System.out.print("3 param rangeIn method range(1, 32, 3): "); printIntArray(list2); 
       int[] list3 = range(1, 12); 
       System.out.print("2 param rangeIn method range(1, 12)   : "); printIntArray(list3); 
       int[] list4 = range(12); 
       System.out.print("1 param rangeIn method range(12)      : "); printIntArray(list4); 
       list2 = range(32, -2, -3); 
       System.out.print("3 param rangeIn method range(32, -2, -3): ");printIntArray(list2); 
       list3 = range(12, 1); 
       System.out.print("2 param rangeIn method range(12, 1)    : ");printIntArray(list3); 
       System.out.print("Creating Stepped Sequence using range(0, 10) method: "); 
       for (int e: range(0, 10)) System.out.print(e+" "); System.out.println();  
    }
}
