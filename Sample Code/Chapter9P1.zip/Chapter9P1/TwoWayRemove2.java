import java.util.ArrayList; 
public class TwoWayRemove2
{
  public static void main(String[] args){
      ArrayList<Integer> numbers = new ArrayList<Integer>(); 
      numbers.add(1); numbers.add(2); numbers.add(3); 
      System.out.println("ArrayList contains: "+numbers); 
      numbers.remove(new Integer(1)); numbers.remove(new Integer(3));
      System.out.println("After removals, ArrayList contains: "+numbers); 
    }
}