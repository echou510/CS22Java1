
/**
 * Write a description of class WeatherGen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WeatherGen
{
    public static void main(String[] args) throws Exception {
    java.io.File file = new java.io.File("Weather3.txt");
    //if (file.exists()){
    //   System.out.println("File already exists"); 
    //   System.exit(0); 
    //}
    
    int i, j; 
    double temp; 
    double humid; 
    java.io.PrintWriter output = new java.io.PrintWriter(file);

        for (i=1; i<11; i++){   // baseline and span of temperature and humidity can be adjusted. 
            for (j=1; j<25; j++){
              output.println(i+ "   "+ j + "  " + (Math.random()*30.0+ 63.0)+ "  " + (Math.random()*0.6+0.34));
              }
        }
        output.close(); 
    }
}
