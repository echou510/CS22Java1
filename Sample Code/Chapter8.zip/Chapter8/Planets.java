
/**
 * Write a description of class Planets here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Planets{
   public enum Planet {
      MERCURY(1),  // pass code to constructor
      VENUS(2),
      EARTH(3), 
      MARS(4),
      JUPITER(5), 
      SATURN(6), 
      URANUS(7), 
      NEPTUNE(8), 
      PLUTO(9); 
      
      private final int starCode;
      
      Planet(int starCode){
          this.starCode = starCode; 
        }
        
      public int get(){
          return this.starCode; 
        }
   }
   
  static String[] p= {
      "Mercury",
      "Venus", 
      "Earth", 
      "Mars",
      "Jupiter", 
      "Saturn", 
      "Uranus", 
      "Netptue", 
      "Pluto" 
    }; 
  
  Planets(){
   }
    
  public static void main(String[] args){
      for (Planet pp: Planet.values()){
          System.out.println("Planet "+pp.get()+" is "+p[pp.get() - 1]); 
        }   
    }
}

