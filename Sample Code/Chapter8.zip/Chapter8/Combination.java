
/**
 * Write a description of class Combination here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Combination
{  
    final static int SIZE = 9; 
    
    public static int c(int n, int m){
       int[][] k = new int[n-m+1][m+1];
       int a = n-m; 
       int b = m; 
       if (a == 0) return 1; 
       if (b == 0) return 1; 
       
       for (int i=0; i<a+1; i++) k[i][0] = 1; 
       for (int j=0; j<b+1; j++) k[0][j] = 1; 
       
       for (int i=1; i<a+1; i++)
          for (int j=1; j<b+1; j++){
             k[i][j] = k[i-1][j] + k[i][j-1]; 
          }
      return k[a][b]; 
    }
    
    public static void main(String[] args){
       System.out.print("Column: "); 
     
       for (int i=0; i<SIZE; i++) System.out.printf("%5d ", i);
       System.out.println(); 
       System.out.println("==================================================================="); 
       
       for (int i=0; i<SIZE; i++){
        System.out.printf("Row "); 
        System.out.printf("%2d", i); 
        System.out.print(": "); 
         for (int j=i; j<SIZE; j++) {
          System.out.printf("%5d ", c(j, i)); 
         }
        System.out.println();
       }
    }
}
