import java.util.Arrays; 
/**
 * Write a description of class AP_ArrayReversal here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AP_ArrayReversal
{
   public static int[] a = {1, 2, 3, 4, 5}; 
   public static int[] b = new int[a.length]; 
   
   public static void main(String[] args){
       System.out.print("\f"); 
       System.out.println("Original: "+Arrays.toString(a)); 
       int top =0; 
       for (int i=0; i<a.length; i++){
           b[top++] = a[i]; 
        }
       for (int i=0; i<b.length; i++){
          a[i] = b[--top]; 
        }
       System.out.println("After Reversal: "+Arrays.toString(a)); 
    }
}
