
/**
 * Write a description of class Stats02 here.
 * 
 * @author (Eric Y. Chou) 
 * @version (11/28/2015)
 */
public class Stats02
{  
    // for even number list test:
    //public static double[] list = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0};
    // for odd number list test: 
    public static double[] list = {1.0, 2.0, 3.0,3.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0,8.0, 9.0, 10.0, 11.0};
    // for mode testing:
    //public static double[] list = {1.0, 3.0, 2.0, 5.0, 4.0, 4.0, 4.0, 4.0, 3.0, 2.0, 4.0, 9.0, 4.0, 3.0, 6.0, 7.0, 4.0, 3.0};
    
    public static void printArray(double[] myList){
        for (int i = 0; i < myList.length; i++) {
            System.out.printf("%8.2f ", myList[i]);
        }
        System.out.println(); 
    }
    
    public static double sum(double[] myList){
        double total = 0;
        for (int i = 0; i < myList.length; i++) {
        total += myList[i];
        }
        return total; 
    }
    
    public static double avg(double[] myList){
        double avg1 = 0;
        avg1 = sum(myList)/myList.length; 
        return avg1; 
    }
    
    public static double max(double[] myList){
        double max1 = myList[0];
        for (int i = 1; i < myList.length; i++) {
          if (myList[i] > max1) max1 = myList[i];
        }
        return max1; 
    }
    
    public static int max(int[] myList){
        int max1 = myList[0];
        for (int i = 1; i < myList.length; i++) {
          if (myList[i] > max1) max1 = myList[i];
        }
        return max1; 
    }
    
    public static double min(double[] myList){
        double min1 = myList[0];
        for (int i = 1; i < myList.length; i++) {
          if (myList[i] < min1) min1 = myList[i];
        }
        return min1; 
    }
    
    public static double median(double[] myList){ // myList must already be sorted. 
       double median1 = 0.0; 
       
       if (myList.length % 2 != 0){
           median1 = myList[myList.length/2];
        }
       else median1 = (myList[myList.length/2]+myList[myList.length/2-1])/2.0;
        
       return median1; 
    }
    
    public static double range(double[] myList){
      double max1 = max(myList); 
      double min1 = min(myList);
      
      return max1-min1; 
    }
    
    public static double mode(double[] myList){
        int[] myMode      = new int[myList.length];
        int[] myModeIndex = new int[myList.length];
        double myMode1 = 0.0; 
        
        for (int i=0; i<myList.length; i++){
          myModeIndex[i] = 0; 
          for (int j=0; j<myList.length; j++){
                if (myList[i]==myList[j]) {myMode[i]++; myModeIndex[i] = j;} // find the last occurence of the same number
            }
        }
        
        int maxMode = max(myMode); 
        for (int k = 0; k<myList.length; k++){
          if (myMode[k] == maxMode) myMode1 = myList[myModeIndex[k]]; 
        }
        return myMode1; 
    }
    
    public static void main(String[] args){
       System.out.print("list: "); 
       printArray(list); 
       System.out.println("Sum    of list: "+sum(list));
       System.out.println("Avg    of list: "+avg(list));
       System.out.println("Max    of list: "+max(list));
       System.out.println("Min    of list: "+min(list));   
       System.out.println("Median of list: "+median(list)); 
       System.out.println("Range  of list: "+range(list));
       System.out.println("Mode   of list: "+mode(list));
    }
}
