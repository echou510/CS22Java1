
/**
 * Write a description of class TestPassString here.
 * 
 * @author (Eric Y. Chou) 
 * @version (11/24/2015)
 */
public class TestPassString
{
   public static String f(String aa){
       String bb = aa; 
       System.out.println("orig address pass to aa("+aa+") and bb("+bb+")"); 
              bb = "XYZ"; 
       System.out.println("aa after modification: "+aa+"    bb after modification: "+bb);
       
       return bb;
    }
   public static void main(String[] args){
       String orig = "ABC"; 
       System.out.println("orig before f(): "+orig); 
       String cc = f(orig); 
       System.out.println("orig after  f():"+orig);
       System.out.println("cc after f():"+cc); 
    }
}
