import java.util.Scanner; 
/**
 * Write a description of class SentinelValue here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 11/21/2015)
 */
public class SentinelValue2{
    	public static void main(String[] args) {
	    // Create a Scanner
	    Scanner input = new Scanner(System.in);

	    // Read an initial data
	    int data = 0;
	    int sum = 0;
	    
	    do {
	      sum += data;
	      // Read the next data
	      System.out.print("Enter an int value (exits if the input is -1): ");
	      data = input.nextInt();
	    }while (data != -1);

	    System.out.println("The sum is " + sum);
	   }

}
