import java.util.Arrays; 
/**
 * Write a description of class MyArrayList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MyArrayList<T>
{   T[] array = (T[]) new Object[10]; 
    int top=0;
    
    MyArrayList(){
    }
    
    public T get(int i){
        if (i>=0 && i<top){
            return array[i]; 
        }
        else  { System.out.println("Index Out of Bound"); return null; }
    }
    
    public void add(T v){
        if (top < array.length) array[top++] = v;  else System.out.println("Full"); 
    }
    
    public String toString(){
      String str = "["; 
      for (int i=0; i<top; i++){
          if (i==0) str += array[i]; 
          else str += ", " + array[i]; 
        }
      str += "]"; 
      return str; 
    }
    
    public static void main(String[] args){
        MyArrayList<Integer> alist = new MyArrayList<Integer>();
        alist.add(1); 
        alist.add(2); 
        alist.add(3); 
        alist.add(4); 
        System.out.println(alist); 
        MyArrayList<Character> blist = new MyArrayList<Character>();
        blist.add('A'); 
        blist.add('B'); 
        blist.add('C'); 
        blist.add('Z'); 
        System.out.println(blist);        
    }
}
