import java.util.ArrayList;
import java.util.Arrays; 
/**
 * Write a description of class NonRecurringList here.
 * 
 * @author (Eiic Y. Chou) 
 * @version (04/10/2017)
 */
public class NonRecurringList
{
   public static int[] NonRecurring(int[] a){
        ArrayList<Integer> alist = new ArrayList<Integer>();
        for (int i=0; i<a.length; i++){
         boolean found=false; 
         for (int j=0; j<alist.size() && !found; j++){
               if (alist.get(j)==a[i]) {
                   found = true;
                }
            }
         if (!found) alist.add(a[i]); 
        }
        int[] b = new int[alist.size()];
        for (int i=0; i<alist.size(); i++) b[i]=alist.get(i);  
        return b; 
    }
   
   public static void printa(int[] a){
      Integer[] b= new Integer[a.length];
      for (int i=0; i<a.length;  i++){
           b[i] = new Integer(a[i]); 
        }
      System.out.println(Arrays.asList(b));
    }
   public static void main(String[] args){
      int[] a={8, 7, 9, 5, 9,8, 9, -3, 2, 0, 17, 5}; 
      System.out.println("\fBefore NonRecurring Selection:"); 
      printa(a); 
      a = NonRecurring(a); 
      System.out.println("After NonRecurring Selection:"); 
      printa(a); 
    }
}
