import java.util.ArrayList;
import java.util.Arrays; 
/**
 * Write a description of class OccurrenceList here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/10/2017)
 */
public class OccurrenceList
{
   public static int[] Occurrence(int[] a, ArrayList<Integer> clist){
        ArrayList<Integer> alist = new ArrayList<Integer>(); 
        for (int i=0; i<a.length; i++){
         boolean found=false; 
         for (int j=0; j<alist.size() && !found; j++){
               if (alist.get(j)==a[i]) {
                   found = true;
                   clist.set(j, (clist.get(j)+1)); 
                }
            }
         if (!found) { alist.add(a[i]); clist.add(new Integer(1)); } 
        }
        int[] b = new int[alist.size()];
        for (int i=0; i<alist.size(); i++) b[i]=alist.get(i);  
        return b; 
    }
   
   public static void printa(int[] a){
      Integer[] b= new Integer[a.length];
      for (int i=0; i<a.length;  i++){
           b[i] = new Integer(a[i]); 
        }
      System.out.println(Arrays.asList(b));
    }
   public static void main(String[] args){
      int[] a={8, 7, 9, 5, 9, 8, 9, -3, 2, 0, 17, 5}; 
      ArrayList<Integer> clist = new ArrayList<Integer>(); 
      System.out.println("\fBefore Occurrenc Count:"); 
      printa(a); 
      a = Occurrence(a, clist); 
      System.out.println("After Occurence Count:"); 
      printa(a); 
      System.out.println(clist); 
    }
}
