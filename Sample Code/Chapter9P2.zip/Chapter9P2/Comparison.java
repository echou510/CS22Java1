import java.util.Arrays; 
import java.util.ArrayList; 
/**
 * Write a description of class Comparison here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/11/2015)
 */
public class Comparison
{
    public static Character[] wrap(char[] charArray){
        Character[] charObjectArray = new Character[charArray.length];
        for (int i=0; i<charArray.length; i++) charObjectArray[i] = Character.valueOf(charArray[i]); 
        return charObjectArray; 
    }
    
    public static char[] unwrap(Character[] charObjectArray){
        char[] charArray = new char[charObjectArray.length];
        for (int i=0;i<charObjectArray.length; i++) charArray[i] = charObjectArray[i].charValue(); 
        return charArray; 
    }
    
    public static void main(String[] args){
       String str = "Java Good!";
       char[] charArray = str.toCharArray();
       System.out.println("String=\""+ str + "\" to char Array=" + Arrays.toString(charArray)); 
       Character[] charObjectArray = wrap(charArray);
       System.out.println("char Array=" + Arrays.toString(charArray) + " to Character Array=" + Arrays.toString(charObjectArray)); 
       ArrayList<Character> charArrayList = new ArrayList<Character>(Arrays.asList(charObjectArray)); 
       System.out.println("Character Array=" + Arrays.toString(charObjectArray) + " to ArrayList=" + charArrayList); 
       Character[] charObjectArray1 = charArrayList.toArray(new Character[charArrayList.size()]); 
       System.out.println("ArrayList=" + charArrayList + " to New Character Array=" + Arrays.toString(charObjectArray1)); 
       char[] charArray1 = unwrap(charObjectArray1); 
       System.out.println("New Character Array=" + Arrays.toString(charObjectArray1) + " to New char Array=" + Arrays.toString(charArray1)); 
       String str1 = new String(charArray1); 
       System.out.println("New char Array=" + Arrays.toString(charArray1) + " to New String=\"" + str1+ "\""); 
    }    
}
