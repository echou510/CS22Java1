
/**
 * Write a description of class NumberLadder here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NumberLadder
{
   public static void main(String [] args){
    for (int i=1; i<=9; i++){
          System.out.println();
          for (int j=1; j<=i; j++){
              System.out.print(j);  
          }
     }
     System.out.println();
   }
}
