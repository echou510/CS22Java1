import java.util.Scanner;
/**
 * Write a description of class StrongPassword here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StrongPassword
{
     public static void main(String[] args){
    //Scanner
    Scanner input = new Scanner(System.in);

    //variables
    int selection      = 0;    // menu selection
    int length         = 100; 
    String password    = "";   // password result
    char pass          = ' ';  // character to be appended
    char passLower     = 'a';  // temporary character buffers
    char passUpper     = 'A';
    char passNumber    = '0';
    char passPunc      = '!';
    int  sel           = 0;    // reused selector
    int  punc          = 0;    // punctuation selection index
    boolean longEnough = true; 
      
    do {   // do-while-loop: top level for Password Generation Menu
      //User Menu 
      password = "";    // reset password for next input
      System.out.println("\n\n\nPassword Generation Menu");
      System.out.println("[1] Lowercase Letters");
      System.out.println("[2] Lowercase & Uppercase Letters");
      System.out.println("[3] Lowercase, Uppercase, and Numbers");
      System.out.println("[4] Lowercase, Uppercase, Numbers, and Punctuation ");
      System.out.println("[5] Quit");
      // making selection
      System.out.print("Enter Selection(1-5): ");
      selection = input.nextInt();
      // if not menu 5: get password length and start computing password. 
      if (selection !=5) {
        // update password length
        System.out.print("Password Length(1-100): ");
        length = input.nextInt();  
        // check if the passwrod is long enough to enforce at least one symbol from every category
        longEnough = true; 
        for (int i = 2; i<=4; i++) if (selection == i && length < i) longEnough = false;
        
        for (int i = 0; i<length; i++){
              passLower  = (char) ((int)(Math.random()*26)+ (int) 'a');  // 97-122
              passUpper  = (char) ((int)(Math.random()*26)+ (int) 'A');  // 65-90
              passNumber = (char) ((int)(Math.random()*10)+ (int) '0');  // 48-57
              
              // passPunc: random punctuation marks and symbols
              punc = ((int) (Math.random()*32));     // create a punctuation index from 1 to 17
              if (punc < 15) { passPunc = (char) (punc + (int) '!'); }                        // region 1 for punctuation 33 - 47
              else if (punc >= 15 && punc < 22) { passPunc = (char) ((punc-15) + (int) ':'); }     // region 2 for punctuation 58 - 64
              else if (punc >=22 && punc < 28) { passPunc = (char) ((punc-22) + (int) '['); }  // region 3 for punctuation 91 - 96
              else { passPunc = (char) ((punc-28) + (int) '{'); }                             // region 4 for punctuation 123-126
                                                                                              
              if (selection == 1){ // begin of selection 1
                 password += passLower;  
                } // end of selection 1
              else if (selection == 2){ // begin of selection 2
                if     (longEnough && i==0)       { pass = passUpper; }    // guaranteed upper for head
                else if(longEnough && i==length-1){ pass = passLower; }    // guaranteed lower for tail
                else { // begin of characters in the middle
                      sel = (int)(Math.random()*2);
                      if      (sel == 0){ pass = passLower; } // random pick for lowercase
                      else if (sel == 1){ pass = passUpper; } // random pick for uppercase
                     }  // characters in the middle
                 password += pass;
                } // end of selection 2
              else if (selection == 3){
                if     (longEnough && i==0)       { pass = passUpper; }    // guaranteed upper for head
                else if(longEnough && i==1)       { pass = passLower; }    // guaranteed lower for head2
                else if(longEnough && i==length-1){ pass = passNumber; }   // guaranteed numbers for tail
                else { // begin of characters in the middle
                      sel = (int)(Math.random()*3);
                      if      (sel == 0){ pass = passLower; } // random pick for lowercase
                      else if (sel == 1){ pass = passUpper; } // random pick for uppercase
                      else if (sel == 2){ pass = passNumber;} // random pick for numbers
                     }  // characters in the middle
                  password += pass;
                    }// end 3rd selection
              else if (selection == 4){
                if     (longEnough && i==0)         { pass = passUpper; }    // guaranteed upper for head
                else if(longEnough && i==1)         { pass = passLower; }    // guaranteed lower for head2
                else if(longEnough && i==length-2)  { pass = passNumber;}    // guaranteed numbers for tail
                else if(longEnough && i == length-1){ pass = passPunc;  }    // guaranteed punctuation for tail2
                else { // begin of characters in the middle
                      sel = (int)(Math.random()*4);
                      if      (sel == 0){ pass = passLower; } // random pick for lowercase
                      else if (sel == 1){ pass = passUpper; } // random pick for uppercase
                      else if (sel == 2){ pass = passNumber;} // random pick for numbers
                      else if (sel == 3){ pass = passPunc; }  // random pick for punctation
                                   }  // characters in the middle
                 password += pass;
              } // end of if-else-if-else-if-else-if for the choice of a character from 4 categories and append it to password
        }  // end of for-loop for password generation  
        System.out.println("password: " + password); 
      } // end of if
    } while (selection != 5);  // end of do while loop  
}
}
