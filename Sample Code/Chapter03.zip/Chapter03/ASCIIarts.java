
/**
 * Write a description of class ASCIIarts here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ASCIIarts
{
    public static void main(String[] args){
      System.out.println("");
      System.out.println("    __________    __________    __________    __________    __________");
      System.out.println("   /\\ .  \\    \\  /\\ .       \\  /\\ .       \\  /\\ .       \\  /\\ .       \\ :: ");
      System.out.println("  /  \\    \\    \\/  \\    \\    \\/  \\    \\    \\/  \\    \\    \\/  \\    _____\\ ::");
      System.out.println("  \\   \\    \\    \\   \\         \\   \\         \\   \\         \\   \\         \\ ::");
      System.out.println("   \\   \\    \\    \\   \\    \\    \\   \\         \\   \\         \\   \\______   \\ :");
      System.out.println("  : \\   \\       . \\   \\    \\   .\\   \\    \\   .\\   \\    \\   .\\  /\\        .\\");
      System.out.println("  :: \\   \\_________\\   \\____\\____\\   \\_________\\   \\_________\\/  \\_________\\");
      System.out.println("   :: \\  /         /\\  /    /    /\\  /         /\\  /         /\\  /         /");
      System.out.println("    :: \\/_________/  \\/____/____/  \\/_________/  \\/_________/  \\/_________/");
    }
}
