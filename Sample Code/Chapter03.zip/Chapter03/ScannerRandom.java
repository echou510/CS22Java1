import java.util.Random; 
import java.util.Scanner; 
/**
 * Write a description of class ScannerRandom here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ScannerRandom
{
   public static void main(String[] args){
      Scanner input = new Scanner(System.in); 
      long time = System.currentTimeMillis(); 
      Random rinput = new Random(); // seed = 100 fixed.  time not fixed
      for (int i=0; i<2; i++){
         System.out.print("Enter :"); 
         int a = input.nextInt(); 
         int b = rinput.nextInt(100);  // 0 to 99,    (int) (Math.random()*100)
         System.out.println(a+" "+b); 
       }
    }
}