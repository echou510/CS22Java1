public class ContnuedFraction
{
   public static void main(String[] args){
       // declaration:
       double decimalValue; 
       
       // assignment: 
       decimalValue = 4.0 + 1.0 / (2.0 + 1.0 / (6.0 + 1.0 / 7.0) ) ;  // put your own expression between = and ; 
       
       // print out the value
       System.out.println("The Output Decimal Value: " + decimalValue);
    }
}
