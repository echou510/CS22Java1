
import java.io.*; 
/**
 * Write a description of class JavadocDemo here.
 * 
 * Add the numbers together
 * 
 * @author (Eric Y. Chou) 
 * @version (V1.0, 10/30/2015)
 */
public class JavadocDemo
{  
    /** 
     *  This method is to calculate the sum of two integers
     *  
     *  @param aa first integer
     *  @param bb second integer
     *  @return sum return the sum of aa and bb
     */
    public static int sum(int aa, int bb){
         return aa + bb; 
    } // end of sum
    
    /**
     *  This method is to print out same result as main to a file. 
     *  
     *  @param aa first integer2
     *  @param bb second integer2
     *  @return void
     */
    public static void printFile(int aa, int bb) throws Exception {
        PrintWriter out = new PrintWriter(new File("Javadoc.txt")); 
        out.println("Sum of " + aa + " and " + bb + " is " + sum(aa, bb));  
        out.close(); 
    } // end of printFile()
    
    /**
     * This is the main function to demo Javadoc
     * 
     * @param args argument list from system console
     * @return void
     */
    public static void main(String[] args){
        int a = 3; 
        int b = 5; 
        System.out.println("Sum of " + a + " and " + b + " is " + sum(a, b)); 
        
        try {
           printFile(a, b); 
        }
        catch(Exception e) {System.out.println("IO Exception !!!"); }
    } // end of main
} // end of class
